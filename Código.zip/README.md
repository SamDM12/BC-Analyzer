\# BC Analyzer



Motor de Recomendación y Dashboard de Campañas Bancarias



\## Equipo 4

\- Aaron Moncada Pérez - 2023097443

\- José Julián Brenes Garro - 2022272865

\- Samuel Durán Maroto - 2023072368

\- Flora Rodríguez Poma - 2023047964



\## Stack Tecnológico

\- \*\*Frontend:\*\* React.js + Vite

\- \*\*Backend:\*\* Express.js + Node.js

\- \*\*Base de Datos:\*\* MongoDB

\- \*\*SO:\*\* Windows



\## Estructura

bc-analyzer/

├── backend/     # API REST

├── frontend/    # Interfaz React

└── docs/        # Documentación

